---
name: Typography
tier: foundation
status: stable
last-updated: 2026-05-02
---

# Typography

> Headings should guide users through search and results. Body copy should be legible and support quick scanning of hotel cards, flight details, and booking information.

Almosafer uses **Open Sans** (from Google Fonts) as the primary typeface. All sizes, weights, and line heights in the Type Scale below are the single source of truth.

---

## Type Scale

| Token | Size | Weight | Line Height | Usage |
|-------|------|--------|-------------|-------|
| `display-xl` | 34px | 600 | 1.2 | Hero titles, page hero |
| `display-lg` | 26px | 600 | 1.23 | Large section headings |
| `display-md` | 22px | 600 | 1.27 | Section headings, titles |
| `heading-lg` | 20px | 600 | 1.3 | Card titles, subsections |
| `heading-md` | 18px | 600 | 1.33 | Form labels, emphasis |
| `body-lg` | 18px | 600 | 1.33 | Emphasized body, CTAs, strong emphasis |
| `body-md` | 16px | 400 | 1.5 | Standard body text |
| `body-sm` | 14px | 400 | 1.43 | Secondary text, captions |
| `label-md` | 14px | 600 | 1.43 | Form labels, small emphasis |
| `label-sm` | 12px | 600 | 1.33 | Badge labels, helper text |
| `caption-md` | 12px | 400 | 1.33 | Disclaimers, fine print |

---

## Usage Guidelines

### Display Tier
Use for hero sections, page titles, and primary entry points.
- `display-xl` (34px, 600) — Full-page hero ("Book Hotels in Jeddah")
- `display-lg` (26px, 600) — Section headers ("Recommended for You")
- `display-md` (22px, 600) — Sub-section headers

### Heading Tier
Use for card titles, form sections, and grouped content.
- `heading-lg` (20px, 600) — Hotel/flight card titles
- `heading-md` (18px, 600) — Filter group headers, subsection titles

### Body Tier
Use for all readable content and primary information.
- `body-lg` (18px, 600) — Emphasized body, CTAs, primary actions, strong emphasis
- `body-md` (16px, 400) — Standard paragraph text
- `body-sm` (14px, 400) — Secondary info, descriptions, metadata

### Label Tier
Use for form labels, badges, and small UI text.
- `label-md` (14px, 600) — Form field labels, small emphasis
- `label-sm` (12px, 600) — Badge text, inline labels
- `caption-md` (12px, 400) — Disclaimers, fine print, helper text

---

## Dos and Don'ts

### ✓ Do

- **Use semantic tokens.** Pick `heading-lg`, not a size. Tokens evolve; names endure.
- **Pair size with weight intentionally.** Larger sizes = lighter weight (34px @ 600). Smaller sizes = heavier weight (12px @ 600).
- **Maintain hierarchy.** Line height increases with body text. Headings tighter. Captions compact.
- **Test on small screens.** Ensure 16px+ base size for mobile readability.

### ✗ Don't

- **Mix font families.** Stick to Open Sans. No serif exceptions.
- **Use weights outside 400–600.** 300 is too light; 700 is redundant.
- **Hardcode sizes.** Never `font-size: 16px`. Always use tokens.
- **Override line height per use case.** Follow the scale. If it doesn't fit, restructure.
- **Forget WCAG contrast.** All text must be ≥4.5:1 for body, ≥3:1 for headings. Test with tools.
- **Add custom letter spacing.** Open Sans is kerned. Letter spacing only when explicitly needed.

---

## Accessibility

### Readability Standards
- **Minimum font size:** 16px on mobile (prevents auto-zoom on iOS input focus)
- **Line height:** 1.5+ for body text on mobile (easier to track lines)
- **Letter spacing:** Keep Open Sans default kerning—only adjust in rare cases

### Touch Targets
When combining text with interactive elements:
- **Minimum height:** 44px (includes padding)
- **Minimum width:** 44px (buttons, links, selectable text areas)

### Typography Hierarchy for Scanning
Use the type scale to create clear visual hierarchy:
1. **Display tier** — Draw attention to primary content
2. **Heading tier** — Organize sections and groupings
3. **Body tier** — Deliver readable content
4. **Label tier** — Support forms and small UI text

This layering helps users quickly scan and find information.

### Testing
- Test all text at actual sizes on mobile (not desktop previews)
- Verify line length (45–75 characters optimal for body text)
- Check that interactive text meets 44px minimum touch target
- Test zoom: all text should remain readable at 200% zoom

---

## Figma Variables

Create these in Figma for design consistency:
- `Typography/Display/XL` → 34px, 600 weight, 1.2 LH
- `Typography/Display/LG` → 26px, 600 weight, 1.23 LH
- `Typography/Display/MD` → 22px, 600 weight, 1.27 LH
- `Typography/Heading/LG` → 20px, 600 weight, 1.3 LH
- `Typography/Heading/MD` → 18px, 600 weight, 1.33 LH
- `Typography/Body/LG` → 18px, 600 weight, 1.33 LH
- `Typography/Body/MD` → 16px, 400 weight, 1.5 LH
- `Typography/Body/SM` → 14px, 400 weight, 1.43 LH
- `Typography/Label/MD` → 14px, 600 weight, 1.43 LH
- `Typography/Label/SM` → 12px, 600 weight, 1.33 LH
- `Typography/Caption/MD` → 12px, 400 weight, 1.33 LH

Link to `Open Sans` Google Font in variables panel.
