---
name: Shadows
tier: foundation
status: stable
last-updated: 2026-05-02
---

# Shadows

Shadows create depth and hierarchy in Almosafer's interface. Use the elevation system to distinguish interactive elements, floating content, and layered components.

> **Shadow color** is sourced from [`color.md`](./color.md) — all shadows use the `Neutral/900` token with varying opacity. Never use pure black or invent new shadow colors.
>
> **Notation:** `Neutral/900 @ 12%` means the `Neutral/900` color token applied at 12% opacity.

---

## Elevation Levels

| Token | Value | Usage |
|-------|-------|-------|
| `shadow-xs` | `0px 1px 2px Neutral/900 @ 12%` | Subtle depth—hover states, borders |
| `shadow-sm` | `0px 2px 4px -1px Neutral/900 @ 20%, 0px 4px 5px 0px Neutral/900 @ 14%, 0px 1px 10px 0px Neutral/900 @ 12%` | Cards, dropdowns, tooltips |
| `shadow-md` | `0px 3px 5px -1px Neutral/900 @ 20%, 0px 6px 10px 0px Neutral/900 @ 14%, 0px 1px 18px 0px Neutral/900 @ 12%` | Modals, floating panels |
| `shadow-lg` | `0px 5px 5px -3px Neutral/900 @ 20%, 0px 8px 10px 1px Neutral/900 @ 14%, 0px 3px 14px 2px Neutral/900 @ 12%` | High-priority modals, overlays |
| `shadow-none` | `none` | Flat surfaces, no elevation |

Color always references `Neutral/900` from [`color.md`](./color.md). Opacity values (12%, 14%, 20%) define elevation depth and stay fixed — only the color token changes if `Neutral/900` is updated upstream.

### Implementation note

In CSS, resolve the token to its hex equivalent with opacity:
- `Neutral/900 @ 12%` → `rgba(51, 51, 51, 0.12)` (or `rgb(from var(--color-neutral-900) r g b / 12%)` in modern CSS)

In Figma, link the shadow's color to the `Neutral/900` variable and set the opacity slider to the specified percentage.

---

## Usage Guidelines

**Use shadows to:**
- Elevate interactive elements (buttons, cards, dropdowns)
- Create layered UI (modals over content)
- Indicate focus or hover states on subtle elements
- Separate floating content from the background

**Avoid:**
- Stacking multiple shadows on one element
- Using shadows as borders (use borders instead)
- Shadows on text (reduces readability)

---

## Dos and Don'ts

### ✓ Do

- **Pick from the scale.** Use defined shadow tokens only.
- **Build upward.** Start with `shadow-xs` for subtle depth, increase if needed.
- **Combine with spacing.** Shadows work best with consistent padding and gaps.
- **Test on all backgrounds.** Ensure shadows remain visible on white, gray, and colored backgrounds.
- **Use the shared color token.** Shadow color always references `Neutral/900` from [`color.md`](./color.md).

### ✗ Don't

- **Create custom shadows.** Stay within the 5 levels.
- **Layer shadows.** One shadow per element.
- **Darken text with shadows.** Use color contrast instead.
- **Use shadows on every element.** Reserve for layered, interactive, or elevated content.
- **Hardcode shadow colors.** Don't use `rgba(0, 0, 0, ...)` or arbitrary hex values — always reference `Neutral/900`.

---

## Figma Variables

Create these in Figma:
- `Shadows/XS` → `0px 1px 2px Neutral/900 @ 12%`
- `Shadows/SM` → `0px 2px 4px -1px Neutral/900 @ 20%, 0px 4px 5px 0px Neutral/900 @ 14%, 0px 1px 10px 0px Neutral/900 @ 12%`
- `Shadows/MD` → `0px 3px 5px -1px Neutral/900 @ 20%, 0px 6px 10px 0px Neutral/900 @ 14%, 0px 1px 18px 0px Neutral/900 @ 12%`
- `Shadows/LG` → `0px 5px 5px -3px Neutral/900 @ 20%, 0px 8px 10px 1px Neutral/900 @ 14%, 0px 3px 14px 2px Neutral/900 @ 12%`
- `Shadows/None` → `none`

Link the shadow color in Figma to the `Neutral/900` variable from [`color.md`](./color.md) so any future change to that token cascades through every shadow automatically. Apply to component layers in Figma's shadow panel.
